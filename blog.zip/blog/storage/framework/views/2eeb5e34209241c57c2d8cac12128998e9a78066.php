<!DOCTYPE html>
<html>
<head>
	<title>Home page</title>
</head>
<body>	

	<h1>Create Post</h1>&nbsp
	<a href="<?php echo e(route('home.index')); ?>">Back</a> |
	<a href="<?php echo e(route('logout')); ?>">Logout</a> <br>

	<form method="post" enctype="multipart/form-data">
		<?php echo e(csrf_field()); ?>

		<table>
			<tr>
				<td>Topic</td>
				<td><input type="text" name="operator" value="<?php echo e(old('operator')); ?>"></td>
			</tr>
			<tr>
				<td>Author</td>
				<td><input type="text" name="manager" value="<?php echo e(old('manager')); ?>"></td>
			</tr>
			<tr>
				<td>Description</td>
				<td><input type="text" name="name" value="<?php echo e(old('name')); ?>"></td>
			</tr>
			
			<tr>
			<tr>
				<td></td>
				<td><input type="submit" name="submit" value="Create"></td>
			</tr>
		</table>
	</form>
	
	<?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $err): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
		<?php echo e($err); ?> <br>
	<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

</body>
</html><?php /**PATH C:\xampp\htdocs\aaaa\blog\resources\views/home/add2.blade.php ENDPATH**/ ?>