<!DOCTYPE html>
<html>
<head>
	<title>Home page</title>
</head>
<body>	

	<h1>Welcome Blog management system!</h1>&nbsp

	<a href="<?php echo e(route('home.list')); ?>">View Users</a> |
	<a href="<?php echo e(route('home.list3')); ?>">Catagory</a> |
	<a href="<?php echo e(route('home.add')); ?>">Create Catagory</a> |
	<a href="<?php echo e(route('home.list2')); ?>">Tags</a> |
	<a href="<?php echo e(route('home.add1')); ?>">Create Tags</a> |
	<a href="<?php echo e(route('home.list1')); ?>">Posts</a> |
	<a href="<?php echo e(route('home.add2')); ?>">Create Post</a> |
	
	<a href="<?php echo e(('logout')); ?>">Logout</a> 

</body>
</html><?php /**PATH C:\xampp\htdocs\aaaa\blog\resources\views/home/index.blade.php ENDPATH**/ ?>