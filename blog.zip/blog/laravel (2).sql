-- phpMyAdmin SQL Dump
-- version 4.8.5
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: May 12, 2020 at 10:55 PM
-- Server version: 10.1.38-MariaDB
-- PHP Version: 7.1.28

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `laravel`
--

-- --------------------------------------------------------

--
-- Table structure for table `admininfo`
--

CREATE TABLE `admininfo` (
  `userId` int(11) NOT NULL,
  `fname` varchar(256) NOT NULL,
  `lname` varchar(256) NOT NULL,
  `username` varchar(256) NOT NULL,
  `password` varchar(256) NOT NULL,
  `email` varchar(256) NOT NULL,
  `phone` varchar(11) NOT NULL,
  `type` varchar(256) NOT NULL,
  `address` varchar(256) NOT NULL,
  `nid` int(17) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `admininfo`
--

INSERT INTO `admininfo` (`userId`, `fname`, `lname`, `username`, `password`, `email`, `phone`, `type`, `address`, `nid`) VALUES
(1, 'Musaddiq Al', 'karim', 'mak01', '1234', 'musaddiqmk19@gmail.com', '01705719021', 'available', 'Bashundhara,Dhaka', 12345);

-- --------------------------------------------------------

--
-- Table structure for table `buscounters`
--

CREATE TABLE `buscounters` (
  `userId` int(20) NOT NULL,
  `operator` varchar(256) NOT NULL,
  `manager` varchar(256) NOT NULL,
  `name` varchar(256) NOT NULL,
  `location` varchar(256) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `buscounters`
--

INSERT INTO `buscounters` (`userId`, `operator`, `manager`, `name`, `location`) VALUES
(1, 'SHOHAGH', 'MR. AB', 'Elite', 'DHK-CTG'),
(2, 'Green Line', 'Mr. C', 'double decker', 'Ctg-Dhk'),
(3, 'Hanif', 'MR. K', 'non - ac', 'CTg-DHK'),
(4, 'Shyamoli', 'manager', 'ac', 'ctg'),
(5, 'ena', 'Musa', 'non-ac', 'ctg');

-- --------------------------------------------------------

--
-- Table structure for table `buses`
--

CREATE TABLE `buses` (
  `userId` int(20) NOT NULL,
  `operator` varchar(256) NOT NULL,
  `manager` varchar(256) NOT NULL,
  `name` varchar(256) NOT NULL,
  `location` varchar(256) NOT NULL,
  `seatRow` int(20) NOT NULL,
  `seatColumn` int(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `buses`
--

INSERT INTO `buses` (`userId`, `operator`, `manager`, `name`, `location`, `seatRow`, `seatColumn`) VALUES
(1, 'Shohagh', 'Manager', 'Elite', 'Dhaka', 10, 3),
(2, 'Green Line', 'Musa', 'Double Deck', 'CTG', 11, 3),
(3, 'Shyamoli', 'Manager', 'Hyundai', 'Dhaka', 10, 4),
(4, 'Silk Line', 'Musa', 'Volvo', 'CTG', 10, 4),
(5, 'Saint martin', 'admin', 'AC', 'ctg', 10, 3);

-- --------------------------------------------------------

--
-- Table structure for table `customers`
--

CREATE TABLE `customers` (
  `userId` int(11) NOT NULL,
  `fname` varchar(256) NOT NULL,
  `lname` varchar(256) NOT NULL,
  `username` varchar(256) NOT NULL,
  `password` varchar(256) NOT NULL,
  `email` varchar(256) NOT NULL,
  `phone` varchar(256) NOT NULL,
  `type` varchar(256) NOT NULL,
  `address` text NOT NULL,
  `nid` varchar(256) NOT NULL,
  `status` varchar(256) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `customers`
--

INSERT INTO `customers` (`userId`, `fname`, `lname`, `username`, `password`, `email`, `phone`, `type`, `address`, `nid`, `status`) VALUES
(2, 'Ashiqul Hoque', 'chowdhury', 'c3', 'c3', 'c3@gmail.com', '01705719021', 'Pending', 'Chandrima,Chandgaon R/A road :04', '0167046408412', 'Unblocked'),
(3, 'Ashiqul Hoque', 'chowdhury', 'h6', 'h6', 'h6@gmail.com', '01705719021', 'Pending', 'Chandrima,Chandgaon R/A road :04', '0167046408412', 'Unblocked'),
(4, 'rasel ', 'mostafa', 'rasel', 'rasel1234', 'rasel@gmail.com', '01201234568', 'Accept', 'dsyguyahsgd', '021554', 'Unblocked');

-- --------------------------------------------------------

--
-- Table structure for table `houseinfos`
--

CREATE TABLE `houseinfos` (
  `houseid` int(20) NOT NULL,
  `housename` varchar(256) NOT NULL,
  `houseowner` varchar(256) NOT NULL,
  `interestedcustomer` varchar(256) NOT NULL,
  `division` varchar(256) NOT NULL,
  `area` varchar(256) NOT NULL,
  `address` varchar(256) NOT NULL,
  `size` int(20) NOT NULL,
  `noofbed` int(20) NOT NULL,
  `rent` int(20) NOT NULL,
  `description` varchar(256) NOT NULL,
  `status` varchar(256) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `houseinfos`
--

INSERT INTO `houseinfos` (`houseid`, `housename`, `houseowner`, `interestedcustomer`, `division`, `area`, `address`, `size`, `noofbed`, `rent`, `description`, `status`) VALUES
(1, 'h1', 'o1', 'c1', 'Dhaka', 'bashundhara', '', 3200, 3, 20000, '3bed, 1 drawing, 1 dining', 'Spam'),
(2, 'h2', 'o2', 'c2', 'Dhaka', 'mothijhil', '', 1900, 2, 15000, '2bed, 1 drawing, 1 dining, 2 washroom', 'Spam'),
(3, 'h3', 'o3', 'c3', 'Chittagong', 'chandgaon', '', 1600, 2, 12000, '2bed, 1 drawing, 1 dining', 'Available');

-- --------------------------------------------------------

--
-- Table structure for table `houseowners`
--

CREATE TABLE `houseowners` (
  `userId` int(11) NOT NULL,
  `fname` varchar(256) NOT NULL,
  `lname` varchar(256) NOT NULL,
  `username` varchar(256) NOT NULL,
  `password` varchar(256) NOT NULL,
  `email` varchar(256) NOT NULL,
  `phone` varchar(256) NOT NULL,
  `nid` varchar(256) NOT NULL,
  `address` varchar(256) NOT NULL,
  `type` varchar(256) NOT NULL,
  `status` varchar(256) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `houseowners`
--

INSERT INTO `houseowners` (`userId`, `fname`, `lname`, `username`, `password`, `email`, `phone`, `nid`, `address`, `type`, `status`) VALUES
(2, 'h2', 'h2', 'h2', 'h2', 'h2@gmail.com', '22', '55', '65', 'Accept', 'Unblocked'),
(3, 'Ashiqul Hoque', 'chowdhury', 'h4', 'h4', 'h4@gmail.com', '01705719021', '0167046408412', 'Chandrima,Chandgaon R/A road :04', 'Pending', 'Unblocked'),
(4, 'Ashiqul Hoque', 'chowdhury', 'h5', 'h5', 'h5@gmail.com', '01705719021', '0167046408412', 'Chandrima,Chandgaon R/A road :04', 'Pending', 'Unblocked');

-- --------------------------------------------------------

--
-- Table structure for table `managers`
--

CREATE TABLE `managers` (
  `userId` int(20) NOT NULL,
  `fname` varchar(256) NOT NULL,
  `lname` varchar(256) NOT NULL,
  `username` varchar(256) NOT NULL,
  `password` varchar(256) NOT NULL,
  `email` varchar(256) NOT NULL,
  `phone` varchar(256) NOT NULL,
  `type` varchar(256) NOT NULL,
  `address` text NOT NULL,
  `nid` varchar(256) NOT NULL,
  `division` varchar(256) NOT NULL,
  `area` varchar(256) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `managers`
--

INSERT INTO `managers` (`userId`, `fname`, `lname`, `username`, `password`, `email`, `phone`, `type`, `address`, `nid`, `division`, `area`) VALUES
(2, 'Ashiqul Hoque', 'chowdhury', 'manager', 'manager', 'ashiqulhoque45@gmail.com', '01670464084', 'Pending', 'Chandrima,Chandgaon R/A road :04', '5454545454545', 'Dhaka', 'Bashundhara'),
(3, 'Musaddiq Al', 'Karim', 'Musa', '1234', 'musaddiqmk19@gmail.com', '01705719021', 'pending', 'Dhaka', '123456789', 'Chittagong', 'Chandanpura');

-- --------------------------------------------------------

--
-- Table structure for table `post`
--

CREATE TABLE `post` (
  `userId` int(11) NOT NULL,
  `topic` varchar(256) NOT NULL,
  `Author` varchar(256) NOT NULL,
  `Description` varchar(256) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `post`
--

INSERT INTO `post` (`userId`, `topic`, `Author`, `Description`) VALUES
(1, 'adjcss', 'laskn', 'askklc');

-- --------------------------------------------------------

--
-- Table structure for table `rentedhouseinfo`
--

CREATE TABLE `rentedhouseinfo` (
  `houseid` int(20) NOT NULL,
  `houseownername` varchar(256) NOT NULL,
  `customername` varchar(256) NOT NULL,
  `area` varchar(256) NOT NULL,
  `date` date NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `rentedhouseinfo`
--

INSERT INTO `rentedhouseinfo` (`houseid`, `houseownername`, `customername`, `area`, `date`) VALUES
(4, 'musaddiq', 'mak', 'bashundhara', '2020-05-01'),
(5, 'h1', 'c1', 'bashundhara', '2020-02-01');

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `userId` int(11) NOT NULL,
  `username` varchar(256) NOT NULL,
  `email` varchar(256) NOT NULL,
  `password` varchar(256) NOT NULL,
  `type` varchar(20) NOT NULL,
  `registered` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`userId`, `username`, `email`, `password`, `type`, `registered`) VALUES
(1, 'admin', 'admin@gmail.com', '1234', 'admin', 'yes'),
(2, 'manager', 'manager@gmail.com', '1234', 'manager', 'yes'),
(3, 'abc', 'abc@gmail.com', '1234', 'manager', 'yes'),
(8, 'new', 'new@gmail.com', '1234', 'staff', 'yes'),
(9, 'Musa', 'musa@gmail.com', '1234', 'manager', 'yes'),
(10, 'musaddiq001', 'mak@gmail.com', '1234', 'manager', 'yes');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `admininfo`
--
ALTER TABLE `admininfo`
  ADD PRIMARY KEY (`userId`);

--
-- Indexes for table `buscounters`
--
ALTER TABLE `buscounters`
  ADD PRIMARY KEY (`userId`);

--
-- Indexes for table `buses`
--
ALTER TABLE `buses`
  ADD PRIMARY KEY (`userId`);

--
-- Indexes for table `post`
--
ALTER TABLE `post`
  ADD PRIMARY KEY (`userId`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`userId`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `admininfo`
--
ALTER TABLE `admininfo`
  MODIFY `userId` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `buscounters`
--
ALTER TABLE `buscounters`
  MODIFY `userId` int(20) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `buses`
--
ALTER TABLE `buses`
  MODIFY `userId` int(20) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `post`
--
ALTER TABLE `post`
  MODIFY `userId` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `userId` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
