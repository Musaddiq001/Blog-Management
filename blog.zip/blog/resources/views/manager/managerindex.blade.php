<!DOCTYPE html>
<html>
<head>
	<title>Home page</title>
</head>
<body>	

	<h1>Welcome User!</h1>&nbsp

	<a href="{{route('home.list')}}">Edit Profile</a> |
	<a href="{{route('home.list3')}}">Catagory</a> |
	<a href="{{route('home.add')}}">Create Catagory</a> |
	<a href="{{route('home.list2')}}">Tags</a> |
	<a href="{{route('home.add1')}}">Create Tags</a> |
	<a href="{{route('home.list1')}}">Posts</a> |
	<a href="{{route('home.add2')}}">Create Post</a> |
	
	<a href="{{('logout')}}">Logout</a> 

</body>
</html>