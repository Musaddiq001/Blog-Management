<!DOCTYPE html>
<html>
<head>
	<title>Home page</title>
</head>
<body>	

	<h1>Tags</h1>&nbsp
	<a href="{{route('home.index')}}">back</a> |
	<a href="/logout">Logout</a> | <br><br> 

	<form method="get" action="{{ route('searchCounter') }}">
	@csrf

		</form>




	<table border="1">
		<tr>
			<th>ID</th>
			<th>Name</th>
			<th>Type</th>
			<th>Catagory</th>
			<th>Date</th>
			<th>ACTION</th>
		</tr>
		
		@foreach($buscounters as $user)
		<tr>
			<td>{{$user['userId']}}</td>
			<td>{{$user['operator']}}</td>
			<td>{{$user['manager']}}</td>
			<td>{{$user['name']}}</td>
			<td>{{$user['location']}}</td>
			<td>
				<a href="{{route('home.delete1', $user['userId'])}}">Delete</a> |
				<a href="{{route('home.edit1', $user['userId'])}}">Edit</a> 
			</td>
		</tr>
		@endforeach
	</table>

</body>
</html>