<!DOCTYPE html>
<html>
<head>
	<title>Home page</title>
</head>
<body>	

	<h1>Create Tag</h1>&nbsp
	<a href="{{route('home.index')}}">Back</a> |
	<a href="{{route('logout')}}">Logout</a> <br>

	<form method="post" enctype="multipart/form-data">
		{{csrf_field()}}
		<table>
			<tr>
				<td>Tag name</td>
				<td><input type="text" name="operator" value="{{old('operator')}}"></td>
			</tr>
			<tr>
				<td>Type</td>
				<td><input type="text" name="manager" value="{{old('manager')}}"></td>
			</tr>
			<tr>
				<td>Catagory</td>
				<td><input type="text" name="name" value="{{old('name')}}"></td>
			</tr>
			<tr>
				<td>Date</td>
				<td><input type="text" name="location" value="{{old('location')}}"></td>
			</tr>
			<tr>
			<tr>
				<td></td>
				<td><input type="submit" name="submit" value="Create"></td>
			</tr>
		</table>
	</form>
	
	@foreach($errors->all() as $err)
		{{$err}} <br>
	@endforeach

</body>
</html>