<!DOCTYPE html>
<html>
<head>
	<title>Home page</title>
</head>
<body>	

	<h1>Catagories List</h1>&nbsp
	<a href="{{route('home.index')}}">back</a> |
	<a href="/logout">Logout</a>  <br> <br>

	<form method="get" action="{{ route('search') }}">
	@csrf
	Search Buses: <input type="search" name="search" >
		<input type="submit" name="submit" value="Search" ><br> <br> 
		Search catagory by name : 

		<input type="text" id="myInput" onkeyup="myFunction()" placeholder="Search by name" title="Type Operator Name">

		</form>

		<table id="myTable" border="1">
		<tr>
			<th>Catagory name</th>
			<th>Type</th>
			<th>Author</th>
			<th>Date</th>
			<th>Number</th>
			<th>ID</th>
			<th>ACTION</th>
		</tr>
		
		@foreach($buses as $user)
		<tr>
			<td>{{$user['operator']}}</td>
			<td>{{$user['manager']}}</td>
			<td>{{$user['name']}}</td>
			<td>{{$user['location']}}</td>
			<td>{{$user['seatRow']}}</td>
			<td>{{$user['seatColumn']}}</td>
			<td>
				<a href="{{route('home.delete', $user['userId'])}}">Delete</a> |
				<a href="{{route('home.edit1', $user['userId'])}}">Edit</a> 
			</td>
		</tr>
		@endforeach
	</table>

	<script>
function myFunction() {
  var input, filter, table, tr, td, i, txtValue;
  input = document.getElementById("myInput");
  filter = input.value.toUpperCase();
  table = document.getElementById("myTable");
  tr = table.getElementsByTagName("tr");
  for (i = 0; i < tr.length; i++) {
    td = tr[i].getElementsByTagName("td")[0];
    if (td) {
      txtValue = td.textContent || td.innerText;
      if (txtValue.toUpperCase().indexOf(filter) > -1) {
        tr[i].style.display = "";
      } else {
        tr[i].style.display = "none";
      }
    }       
  }
}
</script>

</body>
</html>