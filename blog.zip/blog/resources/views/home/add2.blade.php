<!DOCTYPE html>
<html>
<head>
	<title>Home page</title>
</head>
<body>	

	<h1>Create Post</h1>&nbsp
	<a href="{{route('home.index')}}">Back</a> |
	<a href="{{route('logout')}}">Logout</a> <br>

	<form method="post" enctype="multipart/form-data">
		{{csrf_field()}}
		<table>
			<tr>
				<td>Topic</td>
				<td><input type="text" name="operator" value="{{old('operator')}}"></td>
			</tr>
			<tr>
				<td>Author</td>
				<td><input type="text" name="manager" value="{{old('manager')}}"></td>
			</tr>
			<tr>
				<td>Description</td>
				<td><input type="text" name="name" value="{{old('name')}}"></td>
			</tr>
			
			<tr>
			<tr>
				<td></td>
				<td><input type="submit" name="submit" value="Create"></td>
			</tr>
		</table>
	</form>
	
	@foreach($errors->all() as $err)
		{{$err}} <br>
	@endforeach

</body>
</html>