<!DOCTYPE html>
<html>
<head>
	<title>Home page</title>
</head>
<body>	

	<h1>Posts!</h1>&nbsp
	<a href="{{route('home.index')}}">back</a> |
	<a href="/logout">Logout</a> 

	<table border="1">
		<tr>
			<th>ID</th>
			<th>Topic</th>
			<th>Author</th>
			<th>Description</th>
		</tr>
		
		@foreach($post as $user)
		<tr>
			<td>{{$user['userId']}}</td>
			<td>{{$user['topic']}}</td>
			<td>{{$user['Author']}}</td>
			<td>{{$user['Description']}}</td>
			<td>
				<a href="{{route('home.edit', $user['userId'])}}">Edit</a> | 
				<a href="{{route('home.delete', $user['userId'])}}">Delete</a> 
			</td>
		</tr>
		@endforeach
	</table>

</body>
</html>